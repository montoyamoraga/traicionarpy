
# dependencies
import os
import time
import string
import random
import urllib

def depositar(confianza):
    print('depositando confianza...')

def quebrar(confianza):
    print('quebrando confianza...')


def traicionar():
    print('traicionando...')