
# dependencies
import os
import time
import string
import random
import urllib

def iniciar():
    print("iniciando este proceso")

def depositar(confianza):
    print('depositando confianza...')

def quebrar(confianza):
    print('quebrando confianza...')

def traicionar(agente):
    print('traicionando a')

def serTraicionado():
    print('te traicionaron')