# traicionarpy

## Description

A project by Aarón Montoya-Moraga.

## Installation

```bash
pip install traicionar
```

## Use

Import Python module

```Python
import traicionar
```

Functions

```Python
traicionar.depositar(confianza)
traicionar.quebrar(confianza)
traicionar.traicionar()
```

## License

MIT
