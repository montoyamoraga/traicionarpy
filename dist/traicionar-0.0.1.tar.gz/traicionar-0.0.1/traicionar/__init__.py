
# dependencies
import os
import time
import string
import random
import urllib

def traicionar():
    print('traicionando...')