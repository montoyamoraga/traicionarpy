# traicionarpy

## Description

A project by Aarón Montoya-Moraga.

## Installation

```bash
pip install traicionar
```

## License

MIT
